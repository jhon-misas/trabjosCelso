package mundo;

/**
 * Clase que representa una publicación realizada por un usuario.
 * Contiene el texto de la publicación y la fecha/hora de creación.
 * 
 * @author Jhon Misas
 * @author David Mahecha
 */
public class Publicacion {
    
    private String descripcion;  // Contenido/texto de la publicación
    private String timeline;     // Fecha y hora de creación
    
    /**
     * Constructor de la clase Publicacion.
     * 
     * @param descripcion Texto/contenido de la publicación
     * @param timeline Fecha y hora en que se creó la publicación
     */
    public Publicacion(String descripcion, String timeline) {
        this.descripcion = descripcion;
        this.timeline = timeline;
    }
    
    // GETTERS
    public String getDescripcion() { return descripcion; }
    public String getTimeline() { return timeline; }
}