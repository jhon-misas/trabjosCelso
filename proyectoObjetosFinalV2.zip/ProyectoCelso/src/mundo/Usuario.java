package mundo;

import java.util.ArrayList;

/**
 * Clase que representa a un usuario de la red social.
 * Cada usuario tiene un nombre único (username), un nombre real,
 * una lista de publicaciones y una lista de amigos.
 * 
 * @author Jhon Misas
 * @author David Mahecha
 */
public class Usuario {
    
    private String username;           // Identificador único del usuario
    private String nombre;             // Nombre real del usuario
    private ArrayList<Publicacion> publicaciones;  // Lista de publicaciones
    private ArrayList<String> amigos;  // Lista de usernames amigos
    
    // CONSTRUCTOR
    public Usuario(String username, String nombre) {
        this.username = username;
        this.nombre = nombre;
        this.publicaciones = new ArrayList<>();
        this.amigos = new ArrayList<>();
    }
    
    // GETTERS
    public String getUsername() { return username; }
    public String getNombre() { return nombre; }
    public ArrayList<Publicacion> getPublicaciones() { return publicaciones; }
    public ArrayList<String> getAmigos() { return amigos; }
    
    // MÉTODOS
    public void agregarPublicacion(Publicacion pub) { publicaciones.add(pub); }
    public void agregarAmigo(String usernameAmigo) { amigos.add(usernameAmigo); }
}