package mundo;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Clase que representa un grafo de amistades entre usuarios.
 * Utiliza una estructura HashMap donde cada usuario (clave) tiene una lista
 * de sus amigos (valor). Las relaciones son bidireccionales.
 * 
 * @author Jhon Misas
 * @author David Mahecha
 * @version 2.0 
 */
public class GrafoAmistades {

    /**
     * Estructura principal del grafo.
     * Key: Nombre de usuario (String)
     * Value: Lista de amigos de ese usuario (ArrayList<String>)
     */
    private HashMap<String, ArrayList<String>> grafo;

    /**
     * Constructor de la clase GrafoAmistades.
     * Inicializa un nuevo HashMap vacío para almacenar las relaciones.
     */
    public GrafoAmistades() {
        grafo = new HashMap<>();
    }

    /**
     * Agrega un nuevo usuario al grafo.
     * Si el usuario ya existe, no hace nada (putIfAbsent).
     * 
     * @param username Nombre de usuario a agregar
     */
    public void agregarUsuario(String username) {
        grafo.putIfAbsent(username, new ArrayList<>());
    }

    /**
     * Agrega una amistad bidireccional entre dos usuarios.
     * Si alguno de los usuarios no existe en el grafo, lo crea automáticamente.
     * No permite duplicados en la lista de amigos.
     * 
     * @param u1 Primer usuario
     * @param u2 Segundo usuario
     */
    public void agregarAmistad(String u1, String u2) {
        grafo.putIfAbsent(u1, new ArrayList<>());
        grafo.putIfAbsent(u2, new ArrayList<>());

        if (!grafo.get(u1).contains(u2)) {
            grafo.get(u1).add(u2);
        }

        if (!grafo.get(u2).contains(u1)) {
            grafo.get(u2).add(u1);
        }
    }

    /**
     * Obtiene la lista de amigos de un usuario específico.
     * 
     * @param username Nombre del usuario a consultar
     * @return ArrayList con los nombres de los amigos del usuario.
     *         Si el usuario no existe, retorna una lista vacía.
     */
    public ArrayList<String> obtenerAmigos(String username) {
        return grafo.getOrDefault(username, new ArrayList<>());
    }

    /**
     * Verifica si dos usuarios son amigos.
     * 
     * @param u1 Primer usuario
     * @param u2 Segundo usuario
     * @return true si son amigos (existe relación bidireccional),
     *         false en caso contrario o si algún usuario no existe
     */
    public boolean sonAmigos(String u1, String u2) {
        return grafo.containsKey(u1) && grafo.get(u1).contains(u2);
    }

    /**
     * Elimina un usuario del grafo de amistades.
     * 
     * Funcionamiento:
     * 1. Recorre todos los usuarios del grafo
     * 2. Elimina cualquier referencia al usuario eliminado de sus listas de amigos
     * 3. Finalmente, elimina el nodo (usuario) del grafo
     * 
     * Complejidad: O(V + E) donde V es número de usuarios y E es número de amistades
     * 
     * @param username Nombre del usuario a eliminar
     */
    public void eliminarUsuario(String username) {
        // Primero, eliminar todas las referencias a este usuario desde otros nodos
        for (String usuario : grafo.keySet()) {
            ArrayList<String> amigos = grafo.get(usuario);
            amigos.remove(username);
        }
        // Finalmente, eliminar el nodo del usuario
        grafo.remove(username);
    }
}