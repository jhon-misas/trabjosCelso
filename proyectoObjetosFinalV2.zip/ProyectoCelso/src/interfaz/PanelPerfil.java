package interfaz;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import mundo.Usuario;

/**
 * Panel que muestra el perfil del usuario seleccionado.
 * Contiene el nombre, username, número de publicaciones y número de amigos.
 * 
 * @author Jhon Misas
 * @author David Mahecha
 * @version 1.1 
 */
public class PanelPerfil extends JPanel {
    
    private static final long serialVersionUID = 1L;
    
    private JLabel lblNombre;  // Etiqueta para el nombre del usuario
    private JLabel lblInfo;    // Etiqueta para información adicional (@username, publicaciones, amigos)
    private Usuario usuarioActual;  // Usuario que se está mostrando actualmente
    
    /**
     * Constructor del panel de perfil.
     * Configura el layout y las etiquetas iniciales.
     */
    public PanelPerfil() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(15, 20, 15, 20));
        
        // Etiqueta de nombre
        lblNombre = new JLabel("Busca un usuario para ver su perfil");
        lblNombre.setFont(new Font("Arial", Font.BOLD, 16));
        lblNombre.setForeground(new Color(28, 30, 33));
        add(lblNombre);
        
        add(Box.createVerticalStrut(5));
        
        // Etiqueta de información
        lblInfo = new JLabel(" ");
        lblInfo.setFont(new Font("Arial", Font.PLAIN, 12));
        lblInfo.setForeground(new Color(101, 103, 107));
        add(lblInfo);
    }
    
    /**
     * Muestra el perfil de un usuario en el panel.
     * Actualiza las etiquetas con la información del usuario.
     * 
     * @param usuario    Usuario a mostrar
     * @param numAmigos  Número de amigos del usuario
     */
    public void mostrarPerfil(Usuario usuario, int numAmigos) {
        this.usuarioActual = usuario;
        lblNombre.setText(usuario.getNombre());
        
        int numPublicaciones = usuario.getPublicaciones().size();
        
        String info = "@" + usuario.getUsername() + " • " 
                + numPublicaciones + " publicaciones • " 
                + numAmigos + " amigos";
        
        lblInfo.setText(info);
    }
    
    /**
     * Limpia el perfil cuando no hay usuarios en el sistema.
     * Muestra un mensaje indicando que no hay usuarios.
     */
    public void limpiarPerfil() {
        this.usuarioActual = null;
        lblNombre.setText("No hay usuarios en el sistema");
        lblInfo.setText("Crea un nuevo usuario para comenzar");
    }
    
    /**
     * Obtiene el usuario que se está mostrando actualmente.
     * 
     * @return Usuario actual o null si no hay
     */
    public Usuario getUsuarioActual() {
        return usuarioActual;
    }
}