package interfaz;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.util.ArrayList;
import mundo.Usuario;
import mundo.GrafoAmistades;
import mundo.Publicacion;

/**
 * Clase principal de la aplicación Red Social.
 * Extiende JFrame y contiene la ventana principal con todos los paneles.
 * Gestiona usuarios, publicaciones y amistades.
 * 
 * @author Jhon Misas
 * @author David Mahecha
 * @version 2.0 
 */
public class RedSocialSimplificada extends JFrame {
    
    private static final long serialVersionUID = 1L;
    
    // ATRIBUTOS
    private PanelBusqueda panelBusqueda;           // Panel superior con búsqueda y botones
    private PanelPerfil panelPerfil;               // Panel izquierdo con perfil del usuario
    private PanelPublicaciones panelPublicaciones; // Panel derecho con publicaciones
    private ArrayList<Usuario> usuarios;           // Lista de todos los usuarios
    private GrafoAmistades grafo;                  // Grafo para gestionar amistades
    
    /**
     * Constructor de la ventana principal.
     * Configura el tamaño, título, layout y crea los paneles.
     * Carga datos de ejemplo y muestra el primer usuario.
     */
    public RedSocialSimplificada() {
        setTitle("Red Social");
        setSize(700, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout());
        
        // Crear datos de ejemplo
        cargarDatosEjemplo();
        
        // Instanciar paneles
        panelBusqueda = new PanelBusqueda(this);
        panelPerfil = new PanelPerfil();
        panelPublicaciones = new PanelPublicaciones(this);
        
        // Agregar paneles al layout
        JPanel panelCentro = new JPanel();
        panelCentro.setLayout(new BorderLayout());
        panelCentro.add(panelPerfil, BorderLayout.NORTH);
        panelCentro.add(panelPublicaciones, BorderLayout.CENTER);

        add(panelBusqueda, BorderLayout.NORTH);
        add(panelCentro, BorderLayout.CENTER);
        
        // Mostrar usuario de ejemplo al inicio
        mostrarPerfil(usuarios.get(0));
    }
    
    /**
     * Carga datos de ejemplo para la demostración inicial.
     * Crea 3 usuarios de ejemplo y establece amistades entre ellos.
     */
    private void cargarDatosEjemplo() {
        usuarios = new ArrayList<>();
        grafo = new GrafoAmistades();

        Usuario u1 = new Usuario("david_mahecha", "David Mahecha");
        Usuario u2 = new Usuario("jhon_misas", "Jhon Misas");
        Usuario u3 = new Usuario("maria_lopez", "María López");

        // Registrar en grafo
        grafo.agregarUsuario(u1.getUsername());
        grafo.agregarUsuario(u2.getUsername());
        grafo.agregarUsuario(u3.getUsername());

        // Publicaciones de ejemplo
        u1.agregarPublicacion(new Publicacion("¡Primera publicación en la red social!", "Marzo 6, 2025 - 10:00 AM"));
        u1.agregarPublicacion(new Publicacion("Trabajando en el proyecto 💻", "Marzo 7, 2025 - 03:30 PM"));
        u1.agregarPublicacion(new Publicacion("Parcial mañana 📚", "Marzo 8, 2025 - 09:00 PM"));

        // Amistades (grafo)
        grafo.agregarAmistad("david_mahecha", "jhon_misas");
        grafo.agregarAmistad("david_mahecha", "maria_lopez");

        usuarios.add(u1);
        usuarios.add(u2);
        usuarios.add(u3);
    }
    
    /**
     * Agrega un amigo al usuario actual.
     * Solicita el username del amigo por diálogo y verifica que exista.
     */
    public void agregarAmigo() {
        Usuario actual = panelPerfil.getUsuarioActual();

        if (actual == null) return;

        String amigo = JOptionPane.showInputDialog(this, "Username del amigo:");

        if (amigo == null || amigo.isEmpty()) return;

        Usuario encontrado = null;
        for (Usuario u : usuarios) {
            if (u.getUsername().equalsIgnoreCase(amigo)) {
                encontrado = u;
                break;
            }
        }

        if (encontrado == null) {
            JOptionPane.showMessageDialog(this, "Usuario no existe.");
            return;
        }

        if (grafo.sonAmigos(actual.getUsername(), amigo)) {
            JOptionPane.showMessageDialog(this, "Ya son amigos.");
            return;
        }

        grafo.agregarAmistad(actual.getUsername(), amigo);
        JOptionPane.showMessageDialog(this, "Amigo agregado.");
        mostrarPerfil(actual);
    }
    
    /**
     * Agrega una nueva publicación al usuario actual.
     * Solicita el texto por diálogo y genera la fecha automáticamente.
     */
    public void agregarPublicacion() {
        Usuario actual = panelPerfil.getUsuarioActual();

        if (actual == null) {
            return;
        }

        String texto = JOptionPane.showInputDialog(this, "Escribe tu publicación:");

        if (texto == null || texto.isEmpty()) {
            return;
        }

        String fecha = PanelPublicaciones.obtenerFechaActual();
        actual.agregarPublicacion(new Publicacion(texto, fecha));
        mostrarPerfil(actual);
    }
    
    /**
     * Crea un nuevo usuario en el sistema.
     * Solicita username y nombre por diálogo.
     * Verifica que el username no exista previamente.
     */
    public void crearUsuario() {
        String username = JOptionPane.showInputDialog(this, "Username:");
        String nombre = JOptionPane.showInputDialog(this, "Nombre:");

        if (username == null || nombre == null || username.isEmpty() || nombre.isEmpty()) {
            return;
        }

        // Verificar si existe
        for (Usuario u : usuarios) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                JOptionPane.showMessageDialog(this, "El usuario ya existe.");
                return;
            }
        }

        Usuario nuevo = new Usuario(username, nombre);
        usuarios.add(nuevo);
        grafo.agregarUsuario(username);
        JOptionPane.showMessageDialog(this, "Usuario creado correctamente.");
    }
    
    /**
     * Elimina un usuario del sistema.
     * Elimina el usuario actual, todas sus publicaciones y relaciones de amistad.
     * Muestra confirmación antes de eliminar.
     */
    public void eliminarUsuario() {
        Usuario actual = panelPerfil.getUsuarioActual();
        
        if (actual == null) {
            JOptionPane.showMessageDialog(this, "No hay usuario seleccionado.", 
                "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String username = actual.getUsername();
        
        // Confirmar eliminación
        int confirmacion = JOptionPane.showConfirmDialog(this,
            "¿Estás seguro de eliminar al usuario @" + username + "?\n" +
            "Se eliminarán todas sus publicaciones y amistades.",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }
        
        // Eliminar del grafo de amistades
        ArrayList<String> amigos = grafo.obtenerAmigos(username);
        for (String amigo : amigos) {
            ArrayList<String> listaAmigo = grafo.obtenerAmigos(amigo);
            listaAmigo.remove(username);
        }
        grafo.eliminarUsuario(username);
        
        // Eliminar de la lista de usuarios
        usuarios.remove(actual);
        
        // Mostrar otro usuario o limpiar pantalla
        if (!usuarios.isEmpty()) {
            mostrarPerfil(usuarios.get(0));
        } else {
            panelPerfil.limpiarPerfil();
            panelPublicaciones.limpiarPublicaciones();
        }
        
        JOptionPane.showMessageDialog(this, "Usuario @" + username + " eliminado correctamente.");
    }
    
    /**
     * Busca un usuario por su username.
     * 
     * @param username Username a buscar (case insensitive)
     */
    public void buscarUsuario(String username) {
        username = username.trim().toLowerCase();
        
        if (username.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa un username.", 
                "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        Usuario encontrado = null;
        for (Usuario u : usuarios) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                encontrado = u;
                break;
            }
        }
        
        if (encontrado != null) {
            mostrarPerfil(encontrado);
        } else {
            JOptionPane.showMessageDialog(this, "Usuario no encontrado: \"" + username + "\"", 
                "Error de búsqueda", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Muestra el perfil de un usuario en los paneles.
     * Actualiza PanelPerfil y PanelPublicaciones.
     * 
     * @param usuario Usuario a mostrar
     */
    public void mostrarPerfil(Usuario usuario) {
        int numAmigos = grafo.obtenerAmigos(usuario.getUsername()).size();
        panelPerfil.mostrarPerfil(usuario, numAmigos);
        panelPublicaciones.mostrarPublicaciones(usuario);
    }
    
    /**
     * Muestra un diálogo con la lista de amigos del usuario actual.
     */
    public void mostrarAmigos() {
        Usuario usuarioActual = panelPerfil.getUsuarioActual();

        if (usuarioActual == null) return;

        ArrayList<String> amigos = grafo.obtenerAmigos(usuarioActual.getUsername());

        if (amigos.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Sin amigos.");
            return;
        }

        StringBuilder sb = new StringBuilder("Amigos:\n\n");
        for (String a : amigos) {
            sb.append("@").append(a).append("\n");
        }
        JOptionPane.showMessageDialog(this, sb.toString());
    }
    
    /**
     * Método principal que inicia la aplicación.
     * 
     * @param args Argumentos de línea de comandos (no utilizados)
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            RedSocialSimplificada ventana = new RedSocialSimplificada();
            ventana.setVisible(true);
        });
    }
}