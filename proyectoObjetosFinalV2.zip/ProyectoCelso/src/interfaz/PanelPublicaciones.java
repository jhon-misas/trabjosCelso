package interfaz;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import mundo.Usuario;
import mundo.Publicacion;

/**
 * Panel que muestra las publicaciones de un usuario.
 * Cada publicación se muestra en una tarjeta con autor, fecha y contenido.
 * 
 * @author Jhon Misas
 * @author David Mahecha
 * @version 1.1 
 */
public class PanelPublicaciones extends JPanel {
    
    private static final long serialVersionUID = 1L;
    
    private JPanel panelContenido;  // Panel contenedor de las tarjetas de publicaciones
    private RedSocialSimplificada ventana;  // Referencia a la ventana principal

    /**
     * Constructor del panel de publicaciones.
     * 
     * @param ventana Referencia a la ventana principal
     */
    public PanelPublicaciones(RedSocialSimplificada ventana) {
        this.ventana = ventana;

        setLayout(new BorderLayout());
        setBackground(new Color(240, 242, 245));
        
        panelContenido = new JPanel();
        panelContenido.setLayout(new BoxLayout(panelContenido, BoxLayout.Y_AXIS));
        panelContenido.setBackground(new Color(240, 242, 245));
        panelContenido.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Agregar scroll en caso de muchas publicaciones
        JScrollPane scrollPane = new JScrollPane(panelContenido);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        
        add(scrollPane, BorderLayout.CENTER);
    }
    
    /**
     * Muestra todas las publicaciones de un usuario.
     * Limpia el panel y agrega una tarjeta por cada publicación.
     * 
     * @param usuario Usuario cuyas publicaciones se mostrarán
     */
    public void mostrarPublicaciones(Usuario usuario) {
        panelContenido.removeAll();
        
        ArrayList<Publicacion> publicaciones = usuario.getPublicaciones();
        
        if (publicaciones.isEmpty()) {
            JLabel lblVacio = new JLabel("Este usuario no tiene publicaciones.");
            lblVacio.setAlignmentX(Component.CENTER_ALIGNMENT);
            panelContenido.add(lblVacio);
        } else {
            for (Publicacion pub : publicaciones) {
                panelContenido.add(crearTarjetaPublicacion(usuario, pub));
                panelContenido.add(Box.createVerticalStrut(10));
            }
        }
        
        panelContenido.revalidate();
        panelContenido.repaint();
    }
    
    /**
     * Limpia el panel de publicaciones cuando no hay usuarios.
     * Muestra un mensaje indicando que no hay usuarios.
     */
    public void limpiarPublicaciones() {
        panelContenido.removeAll();
        JLabel lblVacio = new JLabel("No hay usuarios para mostrar publicaciones.");
        lblVacio.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelContenido.add(lblVacio);
        panelContenido.revalidate();
        panelContenido.repaint();
    }
    
    /**
     * Crea una tarjeta visual para una publicación.
     * La tarjeta incluye: nombre del autor, fecha y descripción.
     * 
     * @param usuario Usuario autor de la publicación
     * @param pub     Publicación a mostrar
     * @return JPanel con la tarjeta formateada
     */
    private JPanel crearTarjetaPublicacion(Usuario usuario, Publicacion pub) {
        JPanel tarjeta = new JPanel();
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBackground(Color.WHITE);
        tarjeta.setBorder(new CompoundBorder(
                new EmptyBorder(5, 5, 5, 5),
                new CompoundBorder(
                    new LineBorder(new Color(200, 200, 200), 1, true),
                    new EmptyBorder(12, 15, 12, 15)
                )
            ));
        tarjeta.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        tarjeta.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Nombre del autor
        JLabel lblAutor = new JLabel(usuario.getNombre());
        lblAutor.setFont(new Font("Arial", Font.BOLD, 13));
        tarjeta.add(lblAutor);
        
        tarjeta.add(Box.createVerticalStrut(3));
        
        // Fecha de publicación
        JLabel lblTimeline = new JLabel(pub.getTimeline());
        lblTimeline.setFont(new Font("Arial", Font.PLAIN, 11));
        lblTimeline.setForeground(Color.GRAY);
        tarjeta.add(lblTimeline);
        
        tarjeta.add(Box.createVerticalStrut(6));
        
        // Descripción (con soporte HTML para texto largo)
        JLabel lblDescripcion = new JLabel("<html><body style='width:600px'>" 
                + pub.getDescripcion() + "</body></html>");
        tarjeta.add(lblDescripcion);
        
        return tarjeta;
    }

    /**
     * Obtiene la fecha y hora actual formateada.
     * Formato: "dd MMM yyyy - hh:mm a" (ej: "12 May 2026 - 03:45 PM")
     * 
     * @return String con la fecha y hora actual
     */
    public static String obtenerFechaActual() {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd MMM yyyy - hh:mm a");
        return LocalDateTime.now().format(formato);
    }
}