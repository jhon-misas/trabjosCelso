package interfaz;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

/**
 * Panel superior de la aplicación.
 * Contiene la barra de búsqueda y los botones de acción principales.
 * 
 * @author Jhon Misas
 * @author David Mahecha
 * @version 1.0
 */
public class PanelBusqueda extends JPanel {
    
    private static final long serialVersionUID = 1L;
    
    private JTextField txtBuscar;           // Campo de texto para buscar usuarios
    private RedSocialSimplificada ventana;  // Referencia a la ventana principal
    
    /**
     * Constructor del panel de búsqueda.
     * 
     * @param ventana Referencia a la ventana principal para ejecutar acciones
     */
    public PanelBusqueda(RedSocialSimplificada ventana) {
        this.ventana = ventana;
        
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new MatteBorder(0, 0, 1, 0, new Color(220, 222, 224)));
        
        // Contenedor principal
        JPanel contenedor = new JPanel(new BorderLayout());
        contenedor.setBackground(Color.WHITE);
        contenedor.setBorder(new EmptyBorder(10, 20, 10, 20));
        
        // Panel izquierda (BUSCAR)
        JPanel panelBuscar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panelBuscar.setBackground(Color.WHITE);
        
        txtBuscar = new JTextField(15);
        txtBuscar.setPreferredSize(new Dimension(150, 30));
        
        JButton btnBuscar = crearBoton("Buscar", new Color(24,119,242));
        btnBuscar.addActionListener(e -> ventana.buscarUsuario(txtBuscar.getText()));
        
        panelBuscar.add(new JLabel("Buscar:"));
        panelBuscar.add(txtBuscar);
        panelBuscar.add(btnBuscar);
        
        // Panel derecha (BOTONES DE ACCIÓN)
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panelBotones.setBackground(Color.WHITE);
        
        panelBotones.add(crearBotonAccion("Crear", () -> ventana.crearUsuario()));
        panelBotones.add(crearBotonAccion("Publicar", () -> ventana.agregarPublicacion()));
        panelBotones.add(crearBotonAccion("Amigos", () -> ventana.mostrarAmigos()));
        panelBotones.add(crearBotonAccion("Agregar", () -> ventana.agregarAmigo()));
        panelBotones.add(crearBotonAccion("Eliminar", () -> ventana.eliminarUsuario()));
        
        contenedor.add(panelBuscar, BorderLayout.WEST);
        contenedor.add(panelBotones, BorderLayout.EAST);
        
        add(contenedor, BorderLayout.CENTER);
        
        // Acción al presionar Enter en el campo de búsqueda
        txtBuscar.addActionListener(e -> ventana.buscarUsuario(txtBuscar.getText()));
    }
    
    /**
     * Crea un botón con estilo principal (fondo azul, texto blanco).
     * 
     * @param texto Texto del botón
     * @param color Color de fondo del botón
     * @return JButton configurado
     */
    private JButton crearBoton(String texto, Color color) {
        JButton btn = new JButton(texto);
        btn.setForeground(Color.WHITE);
        btn.setBackground(color);
        btn.setFocusPainted(false);
        btn.setBorder(new EmptyBorder(5, 15, 5, 15));
        return btn;
    }
    
    /**
     * Crea un botón con estilo secundario (fondo gris, texto negro).
     * 
     * @param texto  Texto del botón
     * @param accion Acción a ejecutar al hacer clic
     * @return JButton configurado
     */
    private JButton crearBotonAccion(String texto, Runnable accion) {
        JButton btn = new JButton(texto);
        btn.setFocusPainted(false);
        btn.setBackground(new Color(230, 230, 230));
        btn.setBorder(new EmptyBorder(5, 12, 5, 12));
        btn.addActionListener(e -> accion.run());
        return btn;
    }
}