import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.ArrayList;

public class RedSocialSimplificada extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// ─── Estructura de datos ───────────────────────────────────────────────
    static class Publicacion {
        String descripcion;
        String timeline;

        Publicacion(String descripcion, String timeline) {
            this.descripcion = descripcion;
            this.timeline = timeline;
        }
    }

    static class Usuario {
        String username;
        String nombre;
        ArrayList<Publicacion> publicaciones;
        ArrayList<String> amigos;

        Usuario(String username, String nombre) {
            this.username = username;
            this.nombre = nombre;
            this.publicaciones = new ArrayList<>();
            this.amigos = new ArrayList<>();
        }
    }

    // ─── Datos de ejemplo ──────────────────────────────────────────────────
    ArrayList<Usuario> usuarios = new ArrayList<>();

    // ─── Componentes de la interfaz ────────────────────────────────────────
    JTextField txtBuscar;
    JButton btnBuscar;
    JButton btnAmigos;
    JPanel panelPublicaciones;
    JLabel lblNombrePerfil;
    JLabel lblUsernamePerfil;

    public RedSocialSimplificada() {
        cargarDatosEjemplo();
        initUI();
    }

    private void cargarDatosEjemplo() {
        Usuario u1 = new Usuario("david_mahecha", "David Mahecha");
        u1.publicaciones.add(new Publicacion("¡Primera publicación en la red social!", "Marzo 6, 2025 - 10:00 AM"));
        u1.publicaciones.add(new Publicacion("Trabajando en el proyecto de Objetos y Estructuras 💻", "Marzo 7, 2025 - 03:30 PM"));
        u1.publicaciones.add(new Publicacion("Parcial mañana, a estudiar duro 📚", "Marzo 8, 2025 - 09:00 PM"));
        u1.amigos.add("jhon_misas");
        u1.amigos.add("maria_lopez");
        usuarios.add(u1);

        Usuario u2 = new Usuario("jhon_misas", "Jhon Misas");
        u2.publicaciones.add(new Publicacion("Hola a todos, soy nuevo aquí 👋", "Marzo 6, 2025 - 11:00 AM"));
        u2.publicaciones.add(new Publicacion("ArrayList > todo lo demás 😄", "Marzo 7, 2025 - 06:00 PM"));
        u2.amigos.add("david_mahecha");
        usuarios.add(u2);

        Usuario u3 = new Usuario("maria_lopez", "María López");
        u3.publicaciones.add(new Publicacion("Buen día a todos ☀️", "Marzo 5, 2025 - 08:00 AM"));
        u3.amigos.add("david_mahecha");
        u3.amigos.add("jhon_misas");
        usuarios.add(u3);
    }

    private void initUI() {
        setTitle("Red Social Simplificada");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 600);
        setLocationRelativeTo(null);
        setResizable(false);

        // Colores
        Color colorPrimario   = new Color(24, 119, 242);   // azul estilo Facebook
        Color colorFondo      = new Color(240, 242, 245);
        Color colorTarjeta    = Color.WHITE;
        Color colorTextoGris  = new Color(101, 103, 107);

        // ── Panel principal ───────────────────────────────────────────────
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBackground(colorFondo);

        // ── Barra superior (header) ───────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(colorPrimario);
        header.setPreferredSize(new Dimension(700, 55));
        header.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel lblTitulo = new JLabel("  🌐 RedSocial");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(Color.WHITE);

        // Panel de búsqueda
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        panelBusqueda.setOpaque(false);

        txtBuscar = new JTextField(16);
        txtBuscar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtBuscar.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(Color.WHITE, 1, true),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtBuscar.setToolTipText("Ingresa un username");

        btnBuscar = new JButton("BUSCAR");
        estilizarBoton(btnBuscar, Color.WHITE, colorPrimario);

        btnAmigos = new JButton("AMIGOS");
        estilizarBoton(btnAmigos, colorPrimario, Color.WHITE);

        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        panelBusqueda.add(btnAmigos);

        header.add(lblTitulo, BorderLayout.WEST);
        header.add(panelBusqueda, BorderLayout.EAST);

        // ── Panel de perfil ───────────────────────────────────────────────
        JPanel panelPerfil = new JPanel();
        panelPerfil.setLayout(new BoxLayout(panelPerfil, BoxLayout.Y_AXIS));
        panelPerfil.setBackground(colorTarjeta);
        panelPerfil.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 222, 224)),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)));

        lblNombrePerfil = new JLabel("Busca un usuario para ver su perfil");
        lblNombrePerfil.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblNombrePerfil.setForeground(new Color(28, 30, 33));
        lblNombrePerfil.setAlignmentX(Component.LEFT_ALIGNMENT);

        lblUsernamePerfil = new JLabel(" ");
        lblUsernamePerfil.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblUsernamePerfil.setForeground(colorTextoGris);
        lblUsernamePerfil.setAlignmentX(Component.LEFT_ALIGNMENT);

        panelPerfil.add(lblNombrePerfil);
        panelPerfil.add(Box.createVerticalStrut(4));
        panelPerfil.add(lblUsernamePerfil);

        // ── Panel de publicaciones (scrollable) ───────────────────────────
        panelPublicaciones = new JPanel();
        panelPublicaciones.setLayout(new BoxLayout(panelPublicaciones, BoxLayout.Y_AXIS));
        panelPublicaciones.setBackground(colorFondo);
        panelPublicaciones.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JScrollPane scroll = new JScrollPane(panelPublicaciones);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        // ── Ensamblado ────────────────────────────────────────────────────
        JPanel centro = new JPanel(new BorderLayout());
        centro.add(panelPerfil, BorderLayout.NORTH);
        centro.add(scroll, BorderLayout.CENTER);

        panelPrincipal.add(header, BorderLayout.NORTH);
        panelPrincipal.add(centro, BorderLayout.CENTER);

        add(panelPrincipal);

        // ── Acciones ──────────────────────────────────────────────────────
        btnBuscar.addActionListener(e -> buscarUsuario());
        txtBuscar.addActionListener(e -> buscarUsuario()); // también con Enter

        btnAmigos.addActionListener(e -> mostrarAmigos());

        // Mostrar usuario de ejemplo al inicio
        mostrarPerfil(usuarios.get(0));
    }

    // ── Acción BUSCAR ─────────────────────────────────────────────────────
    private void buscarUsuario() {
        String username = txtBuscar.getText().trim().toLowerCase();
        if (username.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa un username.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Usuario encontrado = null;
        for (Usuario u : usuarios) {
            if (u.username.equalsIgnoreCase(username)) {
                encontrado = u;
                break;
            }
        }

        if (encontrado != null) {
            mostrarPerfil(encontrado);
        } else {
            JOptionPane.showMessageDialog(this,
                    "Usuario no encontrado: \"" + username + "\"",
                    "Error de búsqueda",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // ── Mostrar perfil y publicaciones ────────────────────────────────────
    private void mostrarPerfil(Usuario usuario) {
        lblNombrePerfil.setText(usuario.nombre);
        lblUsernamePerfil.setText("@" + usuario.username + "  •  " +
                usuario.publicaciones.size() + " publicaciones  •  " +
                usuario.amigos.size() + " amigos");

        panelPublicaciones.removeAll();

        if (usuario.publicaciones.isEmpty()) {
            JLabel sinPub = new JLabel("Este usuario no tiene publicaciones.");
            sinPub.setFont(new Font("Segoe UI", Font.ITALIC, 13));
            sinPub.setForeground(Color.GRAY);
            panelPublicaciones.add(sinPub);
        } else {
            for (Publicacion pub : usuario.publicaciones) {
                panelPublicaciones.add(crearTarjetaPublicacion(usuario, pub));
                panelPublicaciones.add(Box.createVerticalStrut(12));
            }
        }

        panelPublicaciones.revalidate();
        panelPublicaciones.repaint();
    }

    // ── Tarjeta de publicación ────────────────────────────────────────────
    private JPanel crearTarjetaPublicacion(Usuario usuario, Publicacion pub) {
        JPanel tarjeta = new JPanel();
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBackground(Color.WHITE);
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(220, 222, 224), 1, true),
                BorderFactory.createEmptyBorder(14, 16, 14, 16)));
        tarjeta.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));
        tarjeta.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblAutor = new JLabel(usuario.nombre);
        lblAutor.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblAutor.setForeground(new Color(28, 30, 33));
        lblAutor.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblTimeline = new JLabel(pub.timeline);
        lblTimeline.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblTimeline.setForeground(new Color(101, 103, 107));
        lblTimeline.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblDescripcion = new JLabel("<html><body style='width:580px'>" + pub.descripcion + "</body></html>");
        lblDescripcion.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblDescripcion.setForeground(new Color(28, 30, 33));
        lblDescripcion.setAlignmentX(Component.LEFT_ALIGNMENT);

        tarjeta.add(lblAutor);
        tarjeta.add(Box.createVerticalStrut(2));
        tarjeta.add(lblTimeline);
        tarjeta.add(Box.createVerticalStrut(8));
        tarjeta.add(lblDescripcion);

        return tarjeta;
    }

    // ── Acción AMIGOS ─────────────────────────────────────────────────────
    private void mostrarAmigos() {
        String username = lblUsernamePerfil.getText();
        // Obtener el usuario actualmente visible
        Usuario actual = null;
        for (Usuario u : usuarios) {
            if (username.contains(u.username)) {
                actual = u;
                break;
            }
        }

        if (actual == null || actual.amigos.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Sin amigos registrados.", "Amigos", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder sb = new StringBuilder("Amigos de @" + actual.username + ":\n\n");
        for (int i = 0; i < actual.amigos.size(); i++) {
            sb.append("  ").append(i + 1).append(". @").append(actual.amigos.get(i)).append("\n");
        }

        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);
        area.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        area.setBackground(new Color(240, 242, 245));

        JOptionPane.showMessageDialog(this, area, "Lista de Amigos", JOptionPane.INFORMATION_MESSAGE);
    }

    // ── Estilo de botones ─────────────────────────────────────────────────
    private void estilizarBoton(JButton btn, Color fondo, Color texto) {
        btn.setBackground(fondo);
        btn.setForeground(texto);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(255, 255, 255, 80), 1, true),
                BorderFactory.createEmptyBorder(5, 14, 5, 14)));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    // ── Main ──────────────────────────────────────────────────────────────
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            RedSocialSimplificada app = new RedSocialSimplificada();
            app.setVisible(true);
        });
    }
}