package mundo;

import java.util.ArrayList;

public class Usuario {
    
    private String username;
    private String nombre;
    private ArrayList<Publicacion> publicaciones;
    private ArrayList<String> amigos;
    
    // CONSTRUCTOR
    public Usuario(String username, String nombre) {
        this.username = username;
        this.nombre = nombre;
        this.publicaciones = new ArrayList<>();
        this.amigos = new ArrayList<>();
    }
    
    // GETTERS
    public String getUsername() {
        return username;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public ArrayList<Publicacion> getPublicaciones() {
        return publicaciones;
    }
    
    public ArrayList<String> getAmigos() {
        return amigos;
    }
    
    // MÉTODOS
    public void agregarPublicacion(Publicacion pub) {
        publicaciones.add(pub);
    }
    
    public void agregarAmigo(String usernameAmigo) {
        amigos.add(usernameAmigo);
    }
}