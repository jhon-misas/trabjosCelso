package mundo;

public class Publicacion {
    
    private String descripcion;
    private String timeline;
    
    // CONSTRUCTOR
    public Publicacion(String descripcion, String timeline) {
        this.descripcion = descripcion;
        this.timeline = timeline;
    }
    
    // GETTERS
    public String getDescripcion() {
        return descripcion;
    }
    
    public String getTimeline() {
        return timeline;
    }
}
