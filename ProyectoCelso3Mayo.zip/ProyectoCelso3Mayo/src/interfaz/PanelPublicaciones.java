package interfaz;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.ArrayList;
import mundo.Usuario;
import mundo.Publicacion;

public class PanelPublicaciones extends JPanel {
    
    private static final long serialVersionUID = 1L;
    
    private JPanel panelContenido;
    private JScrollPane scroll;
    
    // CONSTRUCTOR
    public PanelPublicaciones() {
        setLayout(new BorderLayout());
        setBackground(new Color(240, 242, 245));
        
        // Panel interno para las publicaciones
        panelContenido = new JPanel();
        panelContenido.setLayout(new BoxLayout(panelContenido, BoxLayout.Y_AXIS));
        panelContenido.setBackground(new Color(240, 242, 245));
        panelContenido.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Scroll
        scroll = new JScrollPane(panelContenido);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
        add(scroll, BorderLayout.CENTER);
    }
    
    // MÉTODO: Mostrar publicaciones
    public void mostrarPublicaciones(Usuario usuario) {
        panelContenido.removeAll();
        
        ArrayList<Publicacion> publicaciones = usuario.getPublicaciones();
        
        if (publicaciones.isEmpty()) {
            JLabel lblVacio = new JLabel("Este usuario no tiene publicaciones.");
            lblVacio.setFont(new Font("Arial", Font.ITALIC, 12));
            lblVacio.setForeground(Color.GRAY);
            panelContenido.add(lblVacio);
        } else {
            for (Publicacion pub : publicaciones) {
                panelContenido.add(crearTarjetaPublicacion(usuario, pub));
                panelContenido.add(Box.createVerticalStrut(10));
            }
        }
        
        panelContenido.revalidate();
        panelContenido.repaint();
    }
    
    // MÉTODO: Crear tarjeta de publicación
    private JPanel crearTarjetaPublicacion(Usuario usuario, Publicacion pub) {
        JPanel tarjeta = new JPanel();
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBackground(Color.WHITE);
        tarjeta.setBorder(new CompoundBorder(
            new LineBorder(new Color(220, 222, 224), 1, true),
            new EmptyBorder(10, 12, 10, 12)
        ));
        tarjeta.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        
        // Nombre del autor
        JLabel lblAutor = new JLabel(usuario.getNombre());
        lblAutor.setFont(new Font("Arial", Font.BOLD, 13));
        lblAutor.setForeground(new Color(28, 30, 33));
        tarjeta.add(lblAutor);
        
        tarjeta.add(Box.createVerticalStrut(3));
        
        // Timeline
        JLabel lblTimeline = new JLabel(pub.getTimeline());
        lblTimeline.setFont(new Font("Arial", Font.PLAIN, 11));
        lblTimeline.setForeground(new Color(101, 103, 107));
        tarjeta.add(lblTimeline);
        
        tarjeta.add(Box.createVerticalStrut(6));
        
        // Descripción
        JLabel lblDescripcion = new JLabel("<html><body style='width:600px'>" + pub.getDescripcion() + "</body></html>");
        lblDescripcion.setFont(new Font("Arial", Font.PLAIN, 12));
        lblDescripcion.setForeground(new Color(28, 30, 33));
        tarjeta.add(lblDescripcion);
        
        return tarjeta;
    }
}
