package interfaz;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import java.util.ArrayList;
import mundo.Usuario;
import mundo.Publicacion;

public class RedSocialSimplificada extends JFrame {
    
    private static final long serialVersionUID = 1L;
    
    // ATRIBUTOS
    private PanelBusqueda panelBusqueda;
    private PanelPerfil panelPerfil;
    private PanelPublicaciones panelPublicaciones;
    private ArrayList<Usuario> usuarios;
    
    // CONSTRUCTOR
    public RedSocialSimplificada() {
        setTitle("Red Social");
        setSize(700, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout());
        
        // Crear datos de ejemplo
        cargarDatosEjemplo();
        
        // Instanciar paneles
        panelBusqueda = new PanelBusqueda(this);
        panelPerfil = new PanelPerfil();
        panelPublicaciones = new PanelPublicaciones();
        
        // Agregar paneles al layout
        add(panelBusqueda, BorderLayout.NORTH);
        add(panelPerfil, BorderLayout.CENTER);
        add(panelPublicaciones, BorderLayout.SOUTH);
        
        // Mostrar usuario de ejemplo al inicio
        mostrarPerfil(usuarios.get(0));
    }
    
    // MÉTODO: Cargar datos de ejemplo
    private void cargarDatosEjemplo() {
        usuarios = new ArrayList<>();
        
        Usuario u1 = new Usuario("david_mahecha", "David Mahecha");
        u1.agregarPublicacion(new Publicacion("¡Primera publicación en la red social!", "Marzo 6, 2025 - 10:00 AM"));
        u1.agregarPublicacion(new Publicacion("Trabajando en el proyecto de Objetos y Estructuras 💻", "Marzo 7, 2025 - 03:30 PM"));
        u1.agregarPublicacion(new Publicacion("Parcial mañana, a estudiar duro 📚", "Marzo 8, 2025 - 09:00 PM"));
        u1.agregarAmigo("jhon_misas");
        u1.agregarAmigo("maria_lopez");
        usuarios.add(u1);
        
        Usuario u2 = new Usuario("jhon_misas", "Jhon Misas");
        u2.agregarPublicacion(new Publicacion("Hola a todos, soy nuevo aquí 👋", "Marzo 6, 2025 - 11:00 AM"));
        u2.agregarPublicacion(new Publicacion("ArrayList > todo lo demás 😄", "Marzo 7, 2025 - 06:00 PM"));
        u2.agregarAmigo("david_mahecha");
        usuarios.add(u2);
        
        Usuario u3 = new Usuario("maria_lopez", "María López");
        u3.agregarPublicacion(new Publicacion("Buen día a todos ☀️", "Marzo 5, 2025 - 08:00 AM"));
        u3.agregarAmigo("david_mahecha");
        u3.agregarAmigo("jhon_misas");
        usuarios.add(u3);
    }
    
    // MÉTODO: Buscar usuario por username
    public void buscarUsuario(String username) {
        username = username.trim().toLowerCase();
        
        if (username.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa un username.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        Usuario encontrado = null;
        for (Usuario u : usuarios) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                encontrado = u;
                break;
            }
        }
        
        if (encontrado != null) {
            mostrarPerfil(encontrado);
        } else {
            JOptionPane.showMessageDialog(this, "Usuario no encontrado: \"" + username + "\"", 
                "Error de búsqueda", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // MÉTODO: Mostrar perfil del usuario
    public void mostrarPerfil(Usuario usuario) {
        panelPerfil.mostrarPerfil(usuario);
        panelPublicaciones.mostrarPublicaciones(usuario);
    }
    
    // MÉTODO: Mostrar amigos del usuario actual
    public void mostrarAmigos() {
        Usuario usuarioActual = panelPerfil.getUsuarioActual();
        
        if (usuarioActual == null || usuarioActual.getAmigos().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Sin amigos registrados.", "Amigos", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        StringBuilder mensaje = new StringBuilder("Amigos de @" + usuarioActual.getUsername() + ":\n\n");
        ArrayList<String> amigos = usuarioActual.getAmigos();
        for (int i = 0; i < amigos.size(); i++) {
            mensaje.append((i + 1)).append(". @").append(amigos.get(i)).append("\n");
        }
        
        JOptionPane.showMessageDialog(this, mensaje.toString(), "Lista de Amigos", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // MAIN
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            RedSocialSimplificada ventana = new RedSocialSimplificada();
            ventana.setVisible(true);
        });
    }
}