package interfaz;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelBusqueda extends JPanel {
    
    private static final long serialVersionUID = 1L;
    
    private JTextField txtBuscar;
    private JButton btnBuscar;
    private JButton btnAmigos;
    private RedSocialSimplificada ventana;
    
    // CONSTRUCTOR
    public PanelBusqueda(RedSocialSimplificada ventana) {
        this.ventana = ventana;
        
        setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        setBackground(new Color(240, 242, 245));
        setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Etiqueta
        JLabel lblBuscar = new JLabel("Buscar usuario:");
        add(lblBuscar);
        
        // Campo de texto
        txtBuscar = new JTextField(15);
        txtBuscar.setFont(new Font("Arial", Font.PLAIN, 12));
        add(txtBuscar);
        
        // Botón BUSCAR
        btnBuscar = new JButton("BUSCAR");
        btnBuscar.setFont(new Font("Arial", Font.BOLD, 12));
        btnBuscar.setBackground(new Color(24, 119, 242));
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.setFocusPainted(false);
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ventana.buscarUsuario(txtBuscar.getText());
            }
        });
        add(btnBuscar);
        
        // Botón AMIGOS
        btnAmigos = new JButton("VER AMIGOS");
        btnAmigos.setFont(new Font("Arial", Font.BOLD, 12));
        btnAmigos.setBackground(new Color(31, 155, 100));
        btnAmigos.setForeground(Color.WHITE);
        btnAmigos.setFocusPainted(false);
        btnAmigos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ventana.mostrarAmigos();
            }
        });
        add(btnAmigos);
        
        // Permitir búsqueda con Enter
        txtBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ventana.buscarUsuario(txtBuscar.getText());
            }
        });
    }
}