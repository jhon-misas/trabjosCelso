package mundo;

import java.util.ArrayList;
import java.util.HashMap;

public class GrafoAmistades {

    private HashMap<String, ArrayList<String>> grafo;

    public GrafoAmistades() {
        grafo = new HashMap<>();
    }

    // Agregar usuario al grafo
    public void agregarUsuario(String username) {
        grafo.putIfAbsent(username, new ArrayList<>());
    }

    // Agregar amistad (bidireccional)
    public void agregarAmistad(String u1, String u2) {
        grafo.putIfAbsent(u1, new ArrayList<>());
        grafo.putIfAbsent(u2, new ArrayList<>());

        if (!grafo.get(u1).contains(u2)) {
            grafo.get(u1).add(u2);
        }

        if (!grafo.get(u2).contains(u1)) {
            grafo.get(u2).add(u1);
        }
    }

    // Obtener amigos
    public ArrayList<String> obtenerAmigos(String username) {
        return grafo.getOrDefault(username, new ArrayList<>());
    }

    // Verificar amistad
    public boolean sonAmigos(String u1, String u2) {
        return grafo.containsKey(u1) && grafo.get(u1).contains(u2);
    }
 // Eliminar usuario del grafo
    public void eliminarUsuario(String username) {
        // Primero, eliminar todas las referencias a este usuario desde otros nodos
        for (String usuario : grafo.keySet()) {
            ArrayList<String> amigos = grafo.get(usuario);
            amigos.remove(username);
        }
        // Finalmente, eliminar el nodo del usuario
        grafo.remove(username);
    }
}