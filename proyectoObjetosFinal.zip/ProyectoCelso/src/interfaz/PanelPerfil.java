package interfaz;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import mundo.Usuario;

public class PanelPerfil extends JPanel {
    
    private static final long serialVersionUID = 1L;
    
    private JLabel lblNombre;
    private JLabel lblInfo;
    private Usuario usuarioActual;
    
    // CONSTRUCTOR
    public PanelPerfil() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(15, 20, 15, 20));
        
        // Etiqueta de nombre
        lblNombre = new JLabel("Busca un usuario para ver su perfil");
        lblNombre.setFont(new Font("Arial", Font.BOLD, 16));
        lblNombre.setForeground(new Color(28, 30, 33));
        add(lblNombre);
        
        add(Box.createVerticalStrut(5));
        
        // Etiqueta de información
        lblInfo = new JLabel(" ");
        lblInfo.setFont(new Font("Arial", Font.PLAIN, 12));
        lblInfo.setForeground(new Color(101, 103, 107));
        add(lblInfo);
    }
    
    // MÉTODO: Mostrar perfil
    public void mostrarPerfil(Usuario usuario, int numAmigos) {
        this.usuarioActual = usuario;
        lblNombre.setText(usuario.getNombre());
        
        int numPublicaciones = usuario.getPublicaciones().size();
        
        String info = "@" + usuario.getUsername() + " • " 
                + numPublicaciones + " publicaciones • " 
                + numAmigos + " amigos";
        
        lblInfo.setText(info);
    }
    
    // GETTER: Obtener usuario actual
    public Usuario getUsuarioActual() {
        return usuarioActual;
    }
 // MÉTODO: Limpiar perfil (cuando no hay usuarios)
    public void limpiarPerfil() {
        this.usuarioActual = null;
        lblNombre.setText("No hay usuarios en el sistema");
        lblInfo.setText("Crea un nuevo usuario para comenzar");
    }
}