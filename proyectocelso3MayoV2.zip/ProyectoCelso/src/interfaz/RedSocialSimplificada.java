package interfaz;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.util.ArrayList;
import mundo.Usuario;
import mundo.GrafoAmistades;
import mundo.Publicacion;

public class RedSocialSimplificada extends JFrame {
    
    private static final long serialVersionUID = 1L;
    
    // ATRIBUTOS
    private PanelBusqueda panelBusqueda;
    private PanelPerfil panelPerfil;
    private PanelPublicaciones panelPublicaciones;
    private ArrayList<Usuario> usuarios;
    private GrafoAmistades grafo;
    
    // CONSTRUCTOR
    public RedSocialSimplificada() {
        setTitle("Red Social");
        setSize(700, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout());
        
        // Crear datos de ejemplo
        cargarDatosEjemplo();
        
        // Instanciar paneles
        panelBusqueda = new PanelBusqueda(this);
        panelPerfil = new PanelPerfil();
        panelPublicaciones = new PanelPublicaciones(this);
        
        // Agregar paneles al layout
        JPanel panelCentro = new JPanel();
        panelCentro.setLayout(new BorderLayout());

        panelCentro.add(panelPerfil, BorderLayout.NORTH);
        panelCentro.add(panelPublicaciones, BorderLayout.CENTER);

        add(panelBusqueda, BorderLayout.NORTH);
        add(panelCentro, BorderLayout.CENTER);
        
        // Mostrar usuario de ejemplo al inicio
        mostrarPerfil(usuarios.get(0));
    }
    
    // MÉTODO: Cargar datos de ejemplo
    private void cargarDatosEjemplo() {
        usuarios = new ArrayList<>();
        grafo = new GrafoAmistades();

        Usuario u1 = new Usuario("david_mahecha", "David Mahecha");
        Usuario u2 = new Usuario("jhon_misas", "Jhon Misas");
        Usuario u3 = new Usuario("maria_lopez", "María López");

        // Registrar en grafo
        grafo.agregarUsuario(u1.getUsername());
        grafo.agregarUsuario(u2.getUsername());
        grafo.agregarUsuario(u3.getUsername());

        // Publicaciones
        u1.agregarPublicacion(new Publicacion("¡Primera publicación en la red social!", "Marzo 6, 2025 - 10:00 AM"));
        u1.agregarPublicacion(new Publicacion("Trabajando en el proyecto 💻", "Marzo 7, 2025 - 03:30 PM"));
        u1.agregarPublicacion(new Publicacion("Parcial mañana 📚", "Marzo 8, 2025 - 09:00 PM"));

        // Amistades (grafo)
        grafo.agregarAmistad("david_mahecha", "jhon_misas");
        grafo.agregarAmistad("david_mahecha", "maria_lopez");

        usuarios.add(u1);
        usuarios.add(u2);
        usuarios.add(u3);
    }
    //AGREGAR AMIGO(GRAFO)
    public void agregarAmigo() {
        Usuario actual = panelPerfil.getUsuarioActual();

        if (actual == null) return;

        String amigo = JOptionPane.showInputDialog(this, "Username del amigo:");

        if (amigo == null || amigo.isEmpty()) return;

        Usuario encontrado = null;

        for (Usuario u : usuarios) {
            if (u.getUsername().equalsIgnoreCase(amigo)) {
                encontrado = u;
                break;
            }
        }

        if (encontrado == null) {
            JOptionPane.showMessageDialog(this, "Usuario no existe.");
            return;
        }

        if (grafo.sonAmigos(actual.getUsername(), amigo)) {
            JOptionPane.showMessageDialog(this, "Ya son amigos.");
            return;
        }

        grafo.agregarAmistad(actual.getUsername(), amigo);

        JOptionPane.showMessageDialog(this, "Amigo agregado.");
        mostrarPerfil(actual);
    }
    //AGREGAR PUBLICACION
    public void agregarPublicacion() {
        Usuario actual = panelPerfil.getUsuarioActual();

        if (actual == null) {
            return;
        }

        String texto = JOptionPane.showInputDialog(this, "Escribe tu publicación:");

        if (texto == null || texto.isEmpty()) {
            return;
        }

        String fecha = PanelPublicaciones.obtenerFechaActual();

        actual.agregarPublicacion(new Publicacion(texto, fecha));

        mostrarPerfil(actual);
    }
    //CREAR USUARIO
    public void crearUsuario() {
        String username = JOptionPane.showInputDialog(this, "Username:");
        String nombre = JOptionPane.showInputDialog(this, "Nombre:");

        if (username == null || nombre == null || username.isEmpty() || nombre.isEmpty()) {
            return;
        }

        // Verificar si existe
        for (Usuario u : usuarios) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                JOptionPane.showMessageDialog(this, "El usuario ya existe.");
                return;
            }
        }

        Usuario nuevo = new Usuario(username, nombre);
        usuarios.add(nuevo);

        grafo.agregarUsuario(username);

        JOptionPane.showMessageDialog(this, "Usuario creado correctamente.");
    }
    
    // MÉTODO: Buscar usuario por username
    public void buscarUsuario(String username) {
        username = username.trim().toLowerCase();
        
        if (username.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa un username.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        Usuario encontrado = null;
        for (Usuario u : usuarios) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                encontrado = u;
                break;
            }
        }
        
        if (encontrado != null) {
            mostrarPerfil(encontrado);
        } else {
            JOptionPane.showMessageDialog(this, "Usuario no encontrado: \"" + username + "\"", 
                "Error de búsqueda", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // MÉTODO: Mostrar perfil del usuario
    public void mostrarPerfil(Usuario usuario) {

        int numAmigos = grafo.obtenerAmigos(usuario.getUsername()).size();

        panelPerfil.mostrarPerfil(usuario, numAmigos);
        panelPublicaciones.mostrarPublicaciones(usuario);
    }
    
    // MÉTODO: Mostrar amigos del usuario actual
    public void mostrarAmigos() {
        Usuario usuarioActual = panelPerfil.getUsuarioActual();

        if (usuarioActual == null) return;

        ArrayList<String> amigos = grafo.obtenerAmigos(usuarioActual.getUsername());

        if (amigos.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Sin amigos.");
            return;
        }

        StringBuilder sb = new StringBuilder("Amigos:\n\n");

        for (String a : amigos) {
            sb.append("@").append(a).append("\n");
        }

        JOptionPane.showMessageDialog(this, sb.toString());
    }
    
    // MAIN
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            RedSocialSimplificada ventana = new RedSocialSimplificada();
            ventana.setVisible(true);
        });
    }
}