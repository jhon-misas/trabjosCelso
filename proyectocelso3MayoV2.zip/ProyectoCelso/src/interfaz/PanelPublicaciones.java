package interfaz;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import mundo.Usuario;
import mundo.Publicacion;

public class PanelPublicaciones extends JPanel {
    
    private static final long serialVersionUID = 1L;
    
    private JPanel panelContenido;
    private RedSocialSimplificada ventana;

    public PanelPublicaciones(RedSocialSimplificada ventana) {
        this.ventana = ventana;

        setLayout(new BorderLayout());
        setBackground(new Color(240, 242, 245));
        
        panelContenido = new JPanel();
        panelContenido.setLayout(new BoxLayout(panelContenido, BoxLayout.Y_AXIS));
        panelContenido.setBackground(new Color(240, 242, 245));
        panelContenido.setBorder(new EmptyBorder(10, 10, 10, 10));
        
 
        
        add(panelContenido,BorderLayout.CENTER);

        // 🔻 PANEL DE BOTONES ABAJO
        add(panelContenido,BorderLayout.CENTER);
    }
    
    public void mostrarPublicaciones(Usuario usuario) {
        panelContenido.removeAll();
        
        ArrayList<Publicacion> publicaciones = usuario.getPublicaciones();
        
        if (publicaciones.isEmpty()) {
            JLabel lblVacio = new JLabel("Este usuario no tiene publicaciones.");
            panelContenido.add(lblVacio);
        } else {
            for (Publicacion pub : publicaciones) {
                panelContenido.add(crearTarjetaPublicacion(usuario, pub));
                panelContenido.add(Box.createVerticalStrut(10));
            }
        }
        
        panelContenido.revalidate();
        panelContenido.repaint();
    }
    
    private JPanel crearTarjetaPublicacion(Usuario usuario, Publicacion pub) {
        JPanel tarjeta = new JPanel();
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBackground(Color.WHITE);
        tarjeta.setBorder(new CompoundBorder(
        	    new EmptyBorder(5, 5, 5, 5),
        	    new CompoundBorder(
        	        new LineBorder(new Color(200, 200, 200), 1, true),
        	        new EmptyBorder(12, 15, 12, 15)
        	    )
        	));
        tarjeta.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        
        JLabel lblAutor = new JLabel(usuario.getNombre());
        lblAutor.setFont(new Font("Arial", Font.BOLD, 13));
        tarjeta.add(lblAutor);
        
        tarjeta.add(Box.createVerticalStrut(3));
        
        JLabel lblTimeline = new JLabel(pub.getTimeline());
        lblTimeline.setFont(new Font("Arial", Font.PLAIN, 11));
        lblTimeline.setForeground(Color.GRAY);
        tarjeta.add(lblTimeline);
        
        tarjeta.add(Box.createVerticalStrut(6));
        
        JLabel lblDescripcion = new JLabel("<html><body style='width:600px'>" 
                + pub.getDescripcion() + "</body></html>");
        tarjeta.add(lblDescripcion);
        
        return tarjeta;
    }

    // 🔥 MÉTODO PARA FORMATEAR FECHA ACTUAL
    public static String obtenerFechaActual() {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd MMM yyyy - hh:mm a");
        return LocalDateTime.now().format(formato);
    }
}